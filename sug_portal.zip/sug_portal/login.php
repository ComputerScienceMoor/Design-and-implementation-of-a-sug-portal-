<?php
session_start();
include("db.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $matric = $_POST['matric'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM students WHERE matric_no=?");
    $stmt->bind_param("s", $matric);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {

        // Check verification
        if($user['is_verified'] == 0){

            $error = "Please verify your email before first!";

        } else {

            $_SESSION['student_id'] = $user['id'];
            $_SESSION['student_name'] = $user['full_name'];

            header("Location: dashboard.php");
            exit();
        }

    } else {
        $error = "Invalid matric number or password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login - SUG Portal</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="form-container">

<img src="logo.jpeg" class="logo">

<h2>Student Login</h2>

<form method="POST">

<input type="text" name="matric" placeholder="Matric Number" required>

<input type="password" name="password" placeholder="Password" required>

<button type="submit">Login</button>

</form>

<?php if($error){ echo "<p class='error'>$error</p>"; } ?>

<div class="link">
Don't have an account? <a href="register.php">Register</a>
</div>

</div>

</body>
</html>