function sendMessage() {

    let input = document.getElementById("userInput").value;
    let chatbox = document.getElementById("chatbox");

    chatbox.innerHTML += "<p><b>You:</b> " + input + "</p>";

    fetch("chatbot_response.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "message=" + encodeURIComponent(input)
    })
    .then(response => response.text())
    .then(data => {
        chatbox.innerHTML += "<p><b>Bot:</b> " + data + "</p>";
        chatbox.scrollTop = chatbox.scrollHeight;
    });

    document.getElementById("userInput").value = "";
}
