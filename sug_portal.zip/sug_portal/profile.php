<?php
session_start();
include("db.php");

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

$id = $_SESSION['student_id'];

$stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>My Profile</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/profile.css">

<style>



</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
<div>🎓 SUG Portal</div>
<div>
<a href="dashboard.php">Dashboard</a>
<a href="logout.php">Logout</a>
</div>
</div>

<!-- CONTENT -->
<div class="container">

<div class="profile-card">

<img src="uploads/<?php echo $user['profile_pic'] ? $user['profile_pic'] : 'default.png'; ?>" class="profile-img">

<div class="name"><?php echo $user['full_name']; ?></div>

<div class="details">
<p><b>Matric Number:</b> <?php echo $user['matric_no']; ?></p>
<p><b>Email:</b> <?php echo $user['email']; ?></p>
<p><b>Department:</b> <?php echo $user['department']; ?></p>
</div>

<div class="upload-box">
<form action="upload.php" method="POST" enctype="multipart/form-data">
<input type="file" name="profile_pic" required>
<br>
<button type="submit">Upload New Picture</button>
</form>
</div>

</div>

</div>

</body>
</html>