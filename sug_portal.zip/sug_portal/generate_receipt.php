<?php
session_start();

include("db.php");

require('fpdf/fpdf.php');

/* CHECK LOGIN */

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

/* CHECK REFERENCE */

if(!isset($_GET['reference'])){

    die("Invalid receipt access.");

}

$reference = $_GET['reference'];

/* GET PAYMENT */

$stmt = $conn->prepare("
SELECT * FROM payments 
WHERE reference=? 
LIMIT 1
");

$stmt->bind_param("s", $reference);

$stmt->execute();

$result = $stmt->get_result();

if($result->num_rows == 0){

    die("Payment record not found.");

}

$payment = $result->fetch_assoc();

/* PDF */

$pdf = new FPDF();

$pdf->AddPage();

/* LOGO */
$pdf->Image('logo.jpeg',10,10,30);

/* TITLE */
$pdf->SetFont('Arial','B',18);

$pdf->Cell(190,15,'FCAH&PT SUG PAYMENT RECEIPT',0,1,'C');

$pdf->Ln(15);

/* RECEIPT INFO */

$pdf->SetFont('Arial','',13);

$pdf->Cell(60,10,'Student Name:');
$pdf->Cell(100,10,$payment['student_name'],0,1);

$pdf->Cell(60,10,'Matric Number:');
$pdf->Cell(100,10,$payment['matric_no'],0,1);

$pdf->Cell(60,10,'Amount Paid:');
$pdf->Cell(100,10,'NGN '.number_format($payment['amount']),0,1);

$pdf->Cell(60,10,'Payment Reference:');
$pdf->Cell(100,10,$payment['reference'],0,1);

$pdf->Cell(60,10,'Payment Status:');
$pdf->Cell(100,10,'Successful',0,1);

$pdf->Ln(15);

/* FOOTER */

$pdf->SetFont('Arial','I',11);

$pdf->Cell(
190,
10,
'Thank you for your payment.',
0,
1,
'C'
);

/* OUTPUT */

$pdf->Output();
?>