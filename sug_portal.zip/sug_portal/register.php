<?php
session_start();
include("db.php");

/* PHPMailer */
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // GET FORM DATA
    $name = trim($_POST['name']);
    $matric = trim($_POST['matric']);
    $email = trim($_POST['email']);
    $department = trim($_POST['department']);
    $category = strtolower(trim($_POST['category']));
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // CHECK DUPLICATE MATRIC
    $check = $conn->prepare("SELECT id FROM students WHERE matric_no=?");
    $check->bind_param("s", $matric);
    $check->execute();

    $result = $check->get_result();

    if($result->num_rows > 0){

        $message = "<p class='error'>Matric number already exists!</p>";

    } else {

        // GENERATE OTP
        $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

        // INSERT USER
        $stmt = $conn->prepare("
        INSERT INTO students
        (full_name, matric_no, email, department, category, password, verification_code)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "sssssss",
            $name,
            $matric,
            $email,
            $department,
            $category,
            $password,
            $code
        );

        if($stmt->execute()){

            $_SESSION['verify_email'] = $email;

            // SEND EMAIL
            $mail = new PHPMailer(true);

            try{

                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;

                // YOUR GMAIL
                $mail->Username = 'samuelmofopefoluwa@gmail.com';

                // APP PASSWORD
                $mail->Password = 'vvgmqoxdvbjjaodl';

                $mail->SMTPSecure = 'ssl';
                $mail->Port = 465;

                // FIX SSL ISSUES
                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    ]
                ];

                $mail->setFrom(
                    'samuelmofopefoluwa@gmail.com',
                    'FCAH&PT SUG Portal'
                );

                $mail->addAddress($email);

                $mail->isHTML(true);

                $mail->Subject = 'Email Verification Code';

                $mail->Body = "
                <div style='font-family:Arial;padding:20px;'>
                    <h2>FCAH&PT SUG Portal</h2>

                    <p>Your verification code is:</p>

                    <h1 style='color:green;'>$code</h1>

                    <p>Do not share this code with anyone.</p>
                </div>
                ";

                $mail->send();

                header("Location: verify.php");
                exit();

            } catch (Exception $e){

                $message = "
                <p class='error'>
                Email failed: {$mail->ErrorInfo}
                </p>
                ";
            }

        } else {

            $message = "
            <p class='error'>
            Registration failed!
            </p>
            ";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Register - SUG Portal</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="style.css">

<style>

body{
    margin:0;
    font-family:Arial;
    background:#f5f5f5;
}

.form-container{
    width:400px;
    max-width:90%;
    background:white;
    margin:40px auto;
    padding:30px;
    border-radius:10px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

.logo{
    width:80px;
    display:block;
    margin:auto;
}

h2{
    text-align:center;
    color:#064e3b;
}

input, select{
    width:100%;
    padding:12px;
    margin-top:12px;
    border:1px solid #ccc;
    border-radius:6px;
    box-sizing:border-box;
}

button{
    width:100%;
    padding:12px;
    margin-top:18px;
    border:none;
    background:#064e3b;
    color:white;
    font-size:16px;
    border-radius:6px;
    cursor:pointer;
}

button:hover{
    background:#10b981;
}

.link{
    text-align:center;
    margin-top:15px;
}

.link a{
    color:#064e3b;
    text-decoration:none;
    font-weight:bold;
}

.error{
    background:#ffe5e5;
    color:red;
    padding:10px;
    border-radius:5px;
    margin-top:15px;
}

@media(max-width:500px){

.form-container{
    padding:20px;
}

}

</style>

</head>

<body>

<div class="form-container">

<img src="logo.jpeg" class="logo">

<h2>Create Account</h2>

<form method="POST">

<input type="text" name="name" placeholder="Full Name" required>

<input type="text" name="matric" placeholder="Matric Number" required>

<select name="category" required>
    <option value="">Select Category</option>
    <option value="fresher">Fresher</option>
    <option value="staylite">Staylite</option>
</select>

<input type="email" name="email" placeholder="Email Address" required>

<select name="department" required>
    <option value="">Select Department</option>
    <option>Agricultural Technology</option>
    <option>Animal Health ND</option>
    <option>Animal Production</option>
    <option>Animal Health Technology</option>
    <option>Agric Extension</option>
    <option>Biochemistry</option>
    <option>Environmental Biology</option>
    <option>Computer Science</option>
    <option>Fisheries Technology</option>
    <option>Fishries</option>
    <option>Software and Web Development (swd)</option>
    <option>Networking (ncc)</option>
    <option>Science Labouratory Technology (slt)</option>
    <option>Vetinary Labouratory Technology (vlt)</option>
</select>

<input type="password" name="password" placeholder="Password" required>

<button type="submit">Register</button>

</form>

<?php echo $message; ?>

<div class="link">
Already have an account?
<a href="login.php">Login</a>
</div>

</div>

</body>
</html>