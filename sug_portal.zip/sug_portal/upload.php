<?php
session_start();
include("db.php");

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

$id = $_SESSION['student_id'];

if(isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0){

    $file = $_FILES['profile_pic'];

    $filename = $file['name'];
    $tmp = $file['tmp_name'];
    $size = $file['size'];

    // 🔐 ALLOWED EXTENSIONS
    $allowed = ['jpg', 'jpeg', 'png'];

    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    if(!in_array($ext, $allowed)){
        die("❌ Only JPG, JPEG, PNG files allowed!");
    }

    // 🔐 FILE SIZE LIMIT (2MB)
    if($size > 2 * 1024 * 1024){
        die("❌ File too large! Max 2MB allowed.");
    }

    // 🔐 GENERATE UNIQUE FILE NAME
    $new_name = "user_" . $id . "_" . time() . "." . $ext;

    $upload_path = "uploads/" . $new_name;

    // 🔐 MOVE FILE
    if(move_uploaded_file($tmp, $upload_path)){

        // 🔐 DELETE OLD IMAGE (optional)
        $stmt = $conn->prepare("SELECT profile_pic FROM students WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if($user['profile_pic'] != "default.png" && file_exists("uploads/".$user['profile_pic'])){
            unlink("uploads/".$user['profile_pic']);
        }

        // 🔐 UPDATE DATABASE
        $stmt = $conn->prepare("UPDATE students SET profile_pic=? WHERE id=?");
        $stmt->bind_param("si", $new_name, $id);
        $stmt->execute();

        header("Location: profile.php");
        exit();

    } else {
        echo "❌ Failed to upload file.";
    }

} else {
    echo "❌ No file selected or upload error.";
}
?>