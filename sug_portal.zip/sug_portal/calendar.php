<?php
session_start();
include("db.php");

$result = $conn->query("
SELECT *
FROM school_calendar
ORDER BY id DESC
LIMIT 1
");

$calendar = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>Academic Calendar</title>

<link rel="stylesheet" href="css/documents.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>

<body>

<div class="page">

<div class="page-header">

<div>
<h1><i class="fas fa-calendar-alt"></i> Academic Calendar</h1>
<p>View and download the latest school calendar</p>
</div>

</div>

<?php if($calendar){ ?>

<div class="document-card">

<div class="document-info">

<div>

<div class="document-title">
<?php echo $calendar['title']; ?>
</div>

<div class="document-date">
Uploaded:
<?php echo date(
"d M Y",
strtotime($calendar['uploaded_at'])
); ?>
</div>

</div>

<a class="download-btn"
href="uploads/calendar/<?php echo $calendar['file_name']; ?>"
download>

<i class="fas fa-download"></i>
Download

</a>

</div>

<div class="pdf-viewer">

<iframe
src="uploads/calendar/<?php echo $calendar['file_name']; ?>">
</iframe>

</div>

</div>

<?php } else { ?>

<div class="empty-box">

<i class="fas fa-calendar-times"></i>

<h3>No Calendar Available</h3>

<p>
The administrator has not uploaded a calendar yet.
</p>

</div>

<?php } ?>

</div>

</body>
</html>