<?php
session_start();
include("db.php");

/* PHPMailer */
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/* CHECK LOGIN */
if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

/* CHECK REFERENCE */
if(!isset($_GET['reference'])){
    die("No payment reference found.");
}

$reference = $_GET['reference'];

$id = $_SESSION['student_id'];

/* GET STUDENT */
$stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$student = $result->fetch_assoc();

/* AMOUNT */
$category = strtolower(trim($student['category']));

if($category == "fresher"){
    $amount = 5000;
}else{
    $amount = 4500;
}

$check = $conn->prepare("
SELECT id
FROM payments
WHERE reference = ?
");

$check->bind_param("s", $reference);
$check->execute();

$exists = $check->get_result();

if($exists->num_rows > 0){

    header(
    "Location: generate_receipt.php?reference=".$reference
    );

    exit();
}

/* SAVE PAYMENT */
$stmt = $conn->prepare("
INSERT INTO payments
(
student_id,
student_name,
matric_no,
amount,
reference,
payment_date,
verified
)
VALUES
(
?,
?,
?,
?,
?,
NOW(),
1
)
");

$stmt->bind_param(
    "issis",
    $student['id'],
    $student['full_name'],
    $student['matric_no'],
    $amount,
    $reference
);
$stmt->execute();

/* SEND EMAIL */

$mail = new PHPMailer(true);

try{

    $mail->isSMTP();

    $mail->Host = 'smtp.gmail.com';

    $mail->SMTPAuth = true;

    $mail->Username = 'yourgmail@gmail.com';

    $mail->Password = 'your_app_password';

    $mail->SMTPSecure = 'tls';

    $mail->Port = 587;

    $mail->setFrom(
        'yourgmail@gmail.com',
        'SUG Portal'
    );

    $mail->addAddress($student['email']);

    $mail->isHTML(true);

    $mail->Subject = 'SUG Payment Receipt';

    $mail->Body = "
    <h2>Payment Successful</h2>

    <p><b>Reference:</b> $reference</p>

    <p><b>Amount Paid:</b> ₦$amount</p>

    <p>
    Thank you for paying your SUG dues.
    </p>
    ";

    $mail->send();

}catch (Exception $e){

    echo "Email could not be sent.<br>";

    echo $mail->ErrorInfo;
}

/* REDIRECT TO RECEIPT */

header(
"Location: generate_receipt.php?reference=".$reference
);

exit();
?>