<?php
session_start();
include("db.php");

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];


/* MARK ALL AS READ */

$conn->query("
UPDATE notifications 
SET status='read'
WHERE status='unread'
AND (
    student_id='$student_id'
    OR student_id IS NULL
)
");


/* FETCH NOTIFICATIONS */

$result = $conn->query("
SELECT *
FROM notifications
WHERE student_id='$student_id'
OR student_id IS NULL
ORDER BY created_at DESC
");

?>

<!DOCTYPE html>

<html>

<head>

<title>Notifications</title>

<meta name="viewport"
content="width=device-width, initial-scale=1.0">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;
}


body{
background:#f1f5f9;
padding:25px;
}


/* HEADER */

.header{
background:linear-gradient(135deg,#064e3b,#10b981);
color:white;
padding:25px;
border-radius:20px;
margin-bottom:25px;
box-shadow:0 10px 25px rgba(0,0,0,.1);
}


.header h2{
font-size:28px;
}


/* CARD */

.notification-card{
background:white;
padding:20px;
border-radius:15px;
margin-bottom:15px;
box-shadow:0 5px 15px rgba(0,0,0,.06);
border-left:6px solid #10b981;
}


.notification-card h3{
color:#064e3b;
margin-bottom:8px;
}


.notification-card p{
color:#555;
line-height:1.5;
}


.date{
margin-top:10px;
color:#888;
font-size:14px;
}


.empty{
background:white;
padding:40px;
text-align:center;
border-radius:20px;
color:#777;
box-shadow:0 5px 15px rgba(0,0,0,.06);
}


.empty i{
font-size:60px;
color:#10b981;
margin-bottom:15px;
}


.back-btn{

display:inline-block;
margin-top:20px;
background:#064e3b;
color:white;
padding:12px 20px;
text-decoration:none;
border-radius:10px;

}


.back-btn:hover{
background:#047857;
}


</style>


</head>


<body>


<div class="header">

<h2>
<i class="fa-solid fa-bell"></i>
 Notifications
</h2>

<p>
Stay updated with the latest SUG information.
</p>

</div>


<?php if($result->num_rows > 0){ ?>


<?php while($row = $result->fetch_assoc()){ ?>


<div class="notification-card">


<h3>
<?php echo htmlspecialchars($row['title']); ?>
</h3>


<p>
<?php echo htmlspecialchars($row['message']); ?>
</p>


<div class="date">

<i class="fa fa-clock"></i>

<?php echo date(
"d M Y h:i A",
strtotime($row['created_at'])
); ?>


</div>


</div>


<?php } ?>


<?php }else{ ?>


<div class="empty">

<i class="fa-solid fa-bell-slash"></i>

<h3>
No Notifications Yet
</h3>

<p>
You don't have any notifications at the moment.
</p>


</div>


<?php } ?>


<a href="dashboard.php" class="back-btn">

<i class="fa fa-arrow-left"></i>

Back to Dashboard

</a>


</body>

</html>