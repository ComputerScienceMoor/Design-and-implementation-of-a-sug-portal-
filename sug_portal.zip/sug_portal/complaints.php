<?php
session_start();
include("db.php");

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

$message = "";

/* SUBMIT COMPLAINT */

if(isset($_POST['submit'])){

    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];

    $subject = trim($_POST['subject']);
    $complaint = trim($_POST['message']);

    $stmt = $conn->prepare("
        INSERT INTO complaints
        (student_id, student_name, matric_no, subject, message)
        VALUES (?, ?, ?, ?, ?)
    ");

    $matric = $_SESSION['matric_no'];

    $stmt->bind_param(
        "issss",
        $student_id,
        $student_name,
        $matric,
        $subject,
        $complaint
    );
    
    if($stmt->execute()){
        $message = "
        <div class='success'>
        <i class='fas fa-check-circle'></i>
        Your complaint has been submitted successfully.
        </div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Complaints & Feedback</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}


body{
    background:#eef2f7;
    padding:30px;
}


/* HEADER */

.header{
    background:linear-gradient(135deg,#064e3b,#10b981);
    color:white;
    padding:30px;
    border-radius:20px;
    margin-bottom:25px;
    box-shadow:0 15px 30px rgba(0,0,0,.15);
}

.header h1{
    font-size:32px;
    margin-bottom:8px;
}

.header p{
    opacity:.9;
}


/* MAIN GRID */

.dashboard{
    display:grid;
    grid-template-columns:380px 1fr;
    gap:25px;
}


/* CARD */

.card{
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 10px 25px rgba(0,0,0,.08);
}


/* FORM */

.form-icon{
    text-align:center;
    margin-bottom:20px;
}

.form-icon i{
    font-size:50px;
    color:#10b981;
}

.form-icon h2{
    margin-top:10px;
    color:#064e3b;
}


.input-group{
    position:relative;
    margin-bottom:18px;
}


.input-group i{
    position:absolute;
    left:15px;
    top:17px;
    color:#10b981;
}


.input-group input,
.input-group textarea{

    width:100%;
    padding:15px 15px 15px 45px;
    border:1px solid #ddd;
    border-radius:12px;
    outline:none;
    font-size:15px;
}


.input-group textarea{
    height:160px;
    resize:none;
}


.input-group input:focus,
.input-group textarea:focus{

    border-color:#10b981;
    box-shadow:0 0 0 3px rgba(16,185,129,.2);

}


.submit-btn{

    width:100%;
    background:linear-gradient(135deg,#064e3b,#10b981);
    color:white;
    border:none;
    padding:15px;
    border-radius:12px;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:.3s;
}


.submit-btn:hover{

    transform:translateY(-3px);
    box-shadow:0 10px 20px rgba(16,185,129,.4);

}


/* SUCCESS */

.success{

    background:#dcfce7;
    color:#166534;
    padding:15px;
    border-radius:12px;
    margin-bottom:20px;
    font-weight:600;

}


/* HISTORY */

.history-title{

    color:#064e3b;
    margin-bottom:20px;
}


.history{

    max-height:700px;
    overflow-y:auto;

}


.complaint{

    background:#f8fafc;
    padding:20px;
    border-radius:18px;
    margin-bottom:18px;
    border-left:5px solid #10b981;

}


.complaint h3{

    color:#064e3b;
    margin-bottom:10px;

}


.complaint p{

    color:#475569;
    line-height:1.7;

}


/* STATUS */

.badge{

    display:inline-block;
    margin-top:15px;
    padding:8px 15px;
    border-radius:30px;
    font-size:13px;
    font-weight:bold;

}


.pending{

    background:#fef3c7;
    color:#92400e;

}


.progress{

    background:#dbeafe;
    color:#1d4ed8;

}


.resolved{

    background:#dcfce7;
    color:#166534;

}


/* REPLY */

.reply{

    background:white;
    margin-top:15px;
    padding:15px;
    border-radius:12px;
    border-left:4px solid #064e3b;

}


/* EMPTY */

.empty{

    text-align:center;
    color:#64748b;
    padding:40px;

}

.empty i{

    font-size:60px;
    color:#10b981;
    margin-bottom:15px;

}


/* MOBILE */

@media(max-width:900px){

.dashboard{

grid-template-columns:1fr;

}

body{

padding:15px;

}

.header h1{

font-size:24px;

}

}

</style>

</head>

<body>


<div class="header">

<h1>
<i class="fas fa-comments"></i>
 Complaints & Feedback
</h1>

<p>
Communicate directly with the Student Union Government.
</p>

</div>


<?php echo $message; ?>


<div class="dashboard">


<!-- LEFT FORM -->


<div class="card">


<div class="form-icon">

<i class="fas fa-paper-plane"></i>

<h2>Submit Complaint</h2>

</div>


<form method="POST">


<div class="input-group">

<i class="fas fa-heading"></i>

<input 
type="text"
name="subject"
placeholder="Complaint subject"
required>

</div>


<div class="input-group">

<i class="fas fa-pen"></i>

<textarea 
name="message"
placeholder="Write your complaint, suggestion or feedback..."
required></textarea>

</div>


<button 
class="submit-btn"
name="submit">

<i class="fas fa-paper-plane"></i>
 Submit

</button>


</form>

</div>



<!-- RIGHT HISTORY -->


<div class="card">


<h2 class="history-title">

<i class="fas fa-clock-rotate-left"></i>
 Complaint History

</h2>


<div class="history">


<?php

$id = $_SESSION['student_id'];

$result = $conn->query("
SELECT *
FROM complaints
WHERE student_id='$id'
ORDER BY id DESC
");


if($result->num_rows > 0){

while($row = $result->fetch_assoc()){


$class = "pending";

if($row['status']=="In Progress"){
$class = "progress";
}

if($row['status']=="Resolved"){
$class = "resolved";
}

?>


<div class="complaint">


<h3>

<i class="fas fa-file-circle-exclamation"></i>

<?php echo htmlspecialchars($row['subject']); ?>

</h3>


<p>

<?php echo nl2br(htmlspecialchars($row['message'])); ?>

</p>


<span class="badge <?php echo $class; ?>">

<?php echo $row['status']; ?>

</span>



<?php if(!empty($row['admin_reply'])){ ?>


<div class="reply">


<b>
<i class="fas fa-user-shield"></i>
 Admin Reply
</b>

<br><br>

<?php 
echo nl2br(htmlspecialchars($row['admin_reply']));
?>


</div>


<?php } ?>


</div>


<?php

}

}else{

?>


<div class="empty">

<i class="fas fa-folder-open"></i>

<h3>No Complaint Yet</h3>

<p>
Your submitted complaints and feedback will appear here.
</p>

</div>


<?php } ?>


</div>

</div>


</div>


</body>
</html>