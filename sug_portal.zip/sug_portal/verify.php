<?php
session_start();
include("db.php");

$message = "";

if(!isset($_SESSION['verify_email'])){
    header("Location: register.php");
    exit();
}

if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Combine OTP digits
    $code = trim(implode("", $_POST['code']));
    $email = $_SESSION['verify_email'];

    // Get user verification code
    $stmt = $conn->prepare("SELECT verification_code FROM students WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if($result->num_rows > 0){

        $user = $result->fetch_assoc();

        // Convert both to string
        $db_code = strval($user['verification_code']);
        $entered_code = strval($code);

        // Compare
        if($db_code === $entered_code){

            $update = $conn->prepare("UPDATE students SET is_verified=1 WHERE email=?");
            $update->bind_param("s", $email);
            $update->execute();

            unset($_SESSION['verify_email']);

            header("Location: login.php");
            exit();

        } else {
            $message = "<p class='error'>Invalid verification code!</p>";
        }

    } else {
        $message = "<p class='error'>User not found!</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Verify Account</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/verify.css">
</head>

<body>

<div class="container">

<h2>Email Verification</h2>
<p>Enter the 6-digit code sent to your email</p>

<form method="POST" id="otpForm">

<div class="otp-box">
<input type="text" name="code[]" maxlength="1" required>
<input type="text" name="code[]" maxlength="1" required>
<input type="text" name="code[]" maxlength="1" required>
<input type="text" name="code[]" maxlength="1" required>
<input type="text" name="code[]" maxlength="1" required>
<input type="text" name="code[]" maxlength="1" required>
</div>

<button type="submit">Verify</button>

</form>

<div class="timer" id="timer">Resend code in 60s</div>
<div class="resend" id="resendBtn">Resend Code</div>

<?php echo $message; ?>

</div>

<script>

// AUTO MOVE INPUT
const inputs = document.querySelectorAll(".otp-box input");

inputs.forEach((input, index) => {

input.addEventListener("input", () => {
if(input.value.length === 1 && index < inputs.length - 1){
inputs[index + 1].focus();
}
});

// BACKSPACE
input.addEventListener("keydown", (e) => {
if(e.key === "Backspace" && input.value === "" && index > 0){
inputs[index - 1].focus();
}
});

});

// AUTO SUBMIT
document.getElementById("otpForm").addEventListener("input", () => {
let complete = true;

inputs.forEach(input => {
if(input.value === "") complete = false;
});

if(complete){
document.getElementById("otpForm").submit();
}
});

// TIMER
let time = 60;
let timer = document.getElementById("timer");
let resendBtn = document.getElementById("resendBtn");

let countdown = setInterval(() => {
time--;
timer.innerText = "Resend code in " + time + "s";

if(time <= 0){
clearInterval(countdown);
timer.style.display = "none";
resendBtn.style.display = "block";
}
}, 1000);

// RESEND CLICK (UI ONLY)
resendBtn.onclick = function(){
location.reload(); // simple refresh
};

</script>

</body>
</html>