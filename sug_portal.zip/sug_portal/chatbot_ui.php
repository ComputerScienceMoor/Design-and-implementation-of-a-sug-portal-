<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SUG Support Chat</title>

<style>

body{
font-family:'Segoe UI',sans-serif;
background:#f4f6f9;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
margin:0;
}

/* CHAT CONTAINER */

.chat-wrapper{
width:420px;
height:600px;
background:white;
border-radius:12px;
box-shadow:0 10px 30px rgba(0,0,0,0.1);
display:flex;
flex-direction:column;
overflow:hidden;
}

/* HEADER */

.chat-header{
background:#0d4a87;
color:white;
padding:16px;
font-weight:600;
text-align:center;
}

/* CHAT AREA */

.chat-box{
flex:1;
padding:15px;
overflow-y:auto;
background:#f8f9fb;
}

/* BOT MESSAGE */

.bot-message{
background:#e6e9ee;
padding:10px 14px;
border-radius:12px;
margin-bottom:10px;
max-width:75%;
}

/* USER MESSAGE */

.user-message{
background:#0d4a87;
color:white;
padding:10px 14px;
border-radius:12px;
margin-bottom:10px;
max-width:75%;
margin-left:auto;
}

/* QUICK BUTTONS */

.quick-buttons{
padding:10px;
display:flex;
flex-wrap:wrap;
gap:6px;
}

.quick-buttons button{
background:#e6e9ee;
border:none;
padding:6px 10px;
border-radius:15px;
cursor:pointer;
font-size:12px;
}

.quick-buttons button:hover{
background:#0d4a87;
color:white;
}

/* INPUT AREA */

.chat-input-area{
display:flex;
padding:12px;
border-top:1px solid #eee;
background:white;
}

.chat-input-area input{
flex:1;
padding:10px 14px;
border-radius:25px;
border:1px solid #ccc;
outline:none;
}

.chat-input-area button{
margin-left:10px;
padding:10px 18px;
border:none;
background:#0d4a87;
color:white;
border-radius:20px;
cursor:pointer;
}

.chat-input-area button:hover{
background:#08315a;
}

</style>
</head>

<body>

<div class="chat-wrapper">

<div class="chat-header">
🎓 SUG Support Assistant
</div>

<div class="chat-box" id="chatBox">

<div class="bot-message">
Hello 👋 I am your SUG assistant. Ask me about dues, payment, or receipt.
</div>

</div>

<!-- QUICK OPTIONS -->

<div class="quick-buttons">

<button onclick="quickMessage('What is the SUG dues?')">
Check Dues
</button>

<button onclick="quickMessage('Check my payment status')">
Payment Status
</button>

<button onclick="quickMessage('How do I pay my SUG dues')">
Pay SUG Dues
</button>

<button onclick="quickMessage('Download receipt')">
Get Receipt
</button>

</div>

<div class="chat-input-area">

<input 
type="text"
id="userInput"
placeholder="Type your message..."
>

<button onclick="sendMessage()">Send</button>

</div>

</div>

<script>

/* SEND MESSAGE */

function sendMessage(){

let input=document.getElementById("userInput");
let message=input.value.trim();

if(message==="") return;

let chatBox=document.getElementById("chatBox");

/* USER MESSAGE */

let userMsg=document.createElement("div");
userMsg.className="user-message";
userMsg.innerText=message;

chatBox.appendChild(userMsg);

input.value="";

/* SEND MESSAGE TO PHP */

fetch("chatrespond.php",{

method:"POST",

headers:{
"Content-Type":"application/x-www-form-urlencoded"
},

body:"message="+encodeURIComponent(message)

})

.then(response=>response.text())

.then(data=>{

let botMsg=document.createElement("div");
botMsg.className="bot-message";
botMsg.innerHTML=data;

chatBox.appendChild(botMsg);

chatBox.scrollTop=chatBox.scrollHeight;

})

.catch(error=>{

let botMsg=document.createElement("div");
botMsg.className="bot-message";
botMsg.innerText="Server connection error.";

chatBox.appendChild(botMsg);

});

}

/* ENTER KEY SUPPORT */

document.getElementById("userInput").addEventListener("keypress",function(e){

if(e.key==="Enter"){
sendMessage();
}

});

/* QUICK BUTTON FUNCTION */

function quickMessage(text){

document.getElementById("userInput").value=text;

sendMessage();

}

</script>

</body>
</html>