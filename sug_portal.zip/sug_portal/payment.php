<?php
session_start();
include("db.php");

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['student_id'];

$stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$student = $result->fetch_assoc();

/* PAYMENT LOGIC */
$category = strtolower(trim($student['category']));

if($category == "fresher" || $category == "freshers"){
    $amount = 5000;
} 
elseif($category == "staylite" || $category == "stalite"){
    $amount = 4500;
} 
else {
    $amount = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>SUG Payment Portal</title>

<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- GOOGLE FONT -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">

<!-- PAYSTACK -->
<script src="https://js.paystack.co/v1/inline.js"></script>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Inter',sans-serif;
}

body{
background:
linear-gradient(
135deg,
#064e3b 0%,
#065f46 40%,
#f1f5f9 40%,
#f1f5f9 100%
);

min-height:100vh;
display:flex;
justify-content:center;
align-items:center;
padding:20px;
}

/* CARD */
.payment-card{
width:100%;
max-width:500px;
background:rgba(255,255,255,0.95);
backdrop-filter:blur(10px);
border-radius:24px;
padding:35px;
box-shadow:
0 10px 40px rgba(0,0,0,0.08);
position:relative;
overflow:hidden;
}

/* TOP STRIP */
.payment-card::before{
content:'';
position:absolute;
top:0;
left:0;
width:100%;
height:7px;
background:linear-gradient(
90deg,
#10b981,
#064e3b
);
}

/* LOGO */
.logo{
width:90px;
height:90px;
object-fit:cover;
border-radius:50%;
display:block;
margin:auto;
border:4px solid #ecfdf5;
box-shadow:0 4px 15px rgba(0,0,0,0.08);
}

/* TITLE */
.title{
text-align:center;
margin-top:18px;
font-size:28px;
font-weight:700;
color:#064e3b;
}

.subtitle{
text-align:center;
font-size:14px;
color:#6b7280;
margin-top:6px;
margin-bottom:30px;
line-height:1.5;
}

/* STUDENT BOX */
.student-box{
background:#f9fafb;
border:1px solid #e5e7eb;
padding:20px;
border-radius:18px;
margin-bottom:25px;
}

.student-info{
display:flex;
justify-content:space-between;
align-items:center;
padding:12px 0;
border-bottom:1px solid #eee;
}

.student-info:last-child{
border-bottom:none;
}

.label{
display:flex;
align-items:center;
gap:10px;
color:#6b7280;
font-size:14px;
}

.label i{
color:#10b981;
}

.value{
font-weight:600;
font-size:14px;
color:#111827;
}

/* AMOUNT SECTION */
.amount-section{
background:
linear-gradient(
135deg,
#ecfdf5,
#d1fae5
);

padding:30px;
border-radius:20px;
text-align:center;
margin-bottom:25px;
position:relative;
overflow:hidden;
}

.amount-section::before{
content:'';
position:absolute;
top:-30px;
right:-30px;
width:120px;
height:120px;
background:rgba(255,255,255,0.3);
border-radius:50%;
}

.amount-title{
font-size:15px;
color:#065f46;
margin-bottom:10px;
}

.amount{
font-size:48px;
font-weight:800;
color:#064e3b;
letter-spacing:-2px;
}

/* PAY BUTTON */
.pay-btn{
width:100%;
padding:16px;
border:none;
border-radius:16px;
background:linear-gradient(
135deg,
#064e3b,
#10b981
);

color:white;
font-size:16px;
font-weight:600;
cursor:pointer;
transition:0.3s;
box-shadow:
0 8px 20px rgba(16,185,129,0.3);
}

.pay-btn:hover{
transform:translateY(-3px);
box-shadow:
0 12px 25px rgba(16,185,129,0.4);
}

/* SECURITY */
.security{
margin-top:20px;
display:flex;
justify-content:center;
align-items:center;
gap:8px;
font-size:13px;
color:#6b7280;
}

.security i{
color:#10b981;
}

/* RESPONSIVE */
@media(max-width:600px){

.payment-card{
padding:25px;
}

.amount{
font-size:38px;
}

.title{
font-size:24px;
}

}

</style>

</head>

<body>

<div class="payment-card">

<img src="logo.jpeg" class="logo">

<h2 class="title">SUG Dues Payment</h2>

<p class="subtitle">
Federal College of Animal Health & Production Technology
</p>

<!-- STUDENT INFO -->
<div class="student-box">

<div class="student-info">
<span class="label">
<i class="fa-solid fa-user"></i> Student
</span>

<span class="value">
<?php echo $student['full_name']; ?>
</span>
</div>

<div class="student-info">
<span class="label">
<i class="fa-solid fa-id-card"></i> Matric No
</span>

<span class="value">
<?php echo strtoupper($student['matric_no']); ?>
</span>
</div>

<div class="student-info">
<span class="label">
<i class="fa-solid fa-layer-group"></i> Category
</span>

<span class="value">
<?php echo ucfirst($student['category']); ?>
</span>
</div>

</div>

<!-- AMOUNT -->
<div class="amount-box">

<div class="amount-title">
Amount To Pay
</div>

<div class="amount">
₦<?php echo number_format($amount); ?>
</div>

</div>

<!-- PAY BUTTON -->
<button class="pay-btn" onclick="payWithPaystack()">
<i class="fa-solid fa-credit-card"></i>
Pay Now
</button>

<!-- SECURITY -->
<div class="security">
<i class="fa-solid fa-lock"></i>
Secured by Paystack
</div>

</div>

<script>

function payWithPaystack() {

    let handler = PaystackPop.setup({

        key: 'YOUR_PUBLIC_KEY',

        email: "<?php echo $student['email']; ?>",

        amount: <?php echo $amount * 100; ?>,

        currency: "NGN",

        ref: 'SUG_' + Math.floor((Math.random() * 1000000000) + 1),

        callback: function(response){

            window.location.href =
            "verify_payment.php?reference=" + response.reference;

        },

        onClose: function(){

            alert('Payment cancelled');

        }

    });

    handler.openIframe();
}

</script>

</body>
</html>