<?php
session_start();
include("db.php");

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

$id = $_SESSION['student_id'];

// Fetch payments
$stmt = $conn->prepare("SELECT * FROM payments WHERE student_id=? ORDER BY created_at DESC");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment History</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/payment_history.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
<div>🎓 SUG Portal</div>
<div>
<a href="dashboard.php">Dashboard</a>
<a href="payment.php">Pay</a>
<a href="logout.php">Logout</a>
</div>
</div>

<div class="container">

<h2>Payment History</h2>

<table>

<thead>
<tr>
<th>Amount</th>
<th>Reference</th>
<th>Status</th>
<th>Date</th>
</tr>
</thead>

<tbody>

<?php
if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
?>

<tr>
<td>₦<?php echo number_format($row['amount']); ?></td>
<td><?php echo $row['reference']; ?></td>

<td class="<?php echo ($row['status'] == 'success') ? 'success' : 'pending'; ?>">
<?php echo ucfirst($row['status']); ?>
</td>

<td><?php echo date("d M Y, h:i A", strtotime($row['created_at'])); ?></td>
</tr>

<?php
    }
} else {
    echo "<tr><td colspan='4' class='empty'>No payment records found</td></tr>";
}
?>

</tbody>

</table>

</div>

</body>
</html>