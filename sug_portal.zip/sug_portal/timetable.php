<?php
session_start();
include("db.php");

$result = $conn->query("
SELECT *
FROM timetable
ORDER BY id DESC
LIMIT 1
");

$timetable = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>Lecture Timetable</title>

<link rel="stylesheet" href="css/documents.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>

<body>

<div class="page">

<div class="page-header">

<div>
<h1><i class="fas fa-clock"></i> Lecture Timetable</h1>
<p>View and download the latest timetable</p>
</div>

</div>

<?php if($timetable){ ?>

<div class="document-card">

<div class="document-info">

<div>

<div class="document-title">
<?php echo $timetable['title']; ?>
</div>

<div class="document-date">
Uploaded:
<?php echo date(
"d M Y",
strtotime($timetable['uploaded_at'])
); ?>
</div>

</div>

<a class="download-btn"
href="uploads/timetable/<?php echo $timetable['file_name']; ?>"
download>

<i class="fas fa-download"></i>
Download

</a>

</div>

<div class="pdf-viewer">

<iframe
src="uploads/timetable/<?php echo $timetable['file_name']; ?>">
</iframe>

</div>

</div>

<?php } else { ?>

<div class="empty-box">

<i class="fas fa-clock"></i>

<h3>No Timetable Available</h3>

<p>
The administrator has not uploaded a timetable yet.
</p>

</div>

<?php } ?>

</div>

</body>
</html>