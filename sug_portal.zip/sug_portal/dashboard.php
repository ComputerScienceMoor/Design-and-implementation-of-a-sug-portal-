<?php
session_start();
include("db.php");

/* UNREAD NOTIFICATIONS */

$student_id = $_SESSION['student_id'];

$notify = $conn->query("
SELECT COUNT(*) AS total
FROM notifications
WHERE status='unread'
AND (
    student_id='$student_id'
    OR student_id IS NULL
)
");

$notification = $notify->fetch_assoc();

$unread = $notification['total'];

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

$student_name = isset($_SESSION['student_name']) 
? $_SESSION['student_name'] 
: "Student";
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Student Dashboard</title>

<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- GOOGLE FONT -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Inter',sans-serif;
}

body{
background:#f1f5f9;
display:flex;
min-height:100vh;
}

/* SIDEBAR */

.sidebar{
width:260px;
background:#064e3b;
padding: 15px;
position:fixed;
height:100%;
color:white;
}

.logo{
text-align:center;
margin-bottom:20px;
}

.logo img{
width:85px;
margin-bottom:10px;
border-radius: 50%;
}

.logo h2{
font-size:22px;
font-weight:700;
}

.sidebar a{
display:flex;
align-items:center;
gap:12px;
padding:14px;
margin-bottom:5px;
text-decoration:none;
color:white;
border-radius:12px;
transition:0.3s;
font-size:15px;
font-weight:500;
}

.sidebar a:hover,
.sidebar .active{
background:#10b981;
}

/* MAIN CONTENT */

.main{
margin-left:260px;
width:100%;
}

/* TOPBAR */

.topbar{
height:75px;
background:white;
display:flex;
justify-content:space-between;
align-items:center;
padding:0 30px;
box-shadow:0 2px 12px rgba(0,0,0,0.05);
}

.topbar h3{
color:#064e3b;
font-size:22px;
}

.user-box{
display:flex;
align-items:center;
gap:12px;
font-weight:600;
color:#111827;
}

.user-box i{
font-size:28px;
color:#064e3b;
}

/* CONTENT */

.content{
padding:30px;
}

/* WELCOME CARD */

.welcome-card{
background:linear-gradient(135deg,#064e3b,#10b981);
padding:35px;
border-radius:22px;
color:white;
margin-bottom:30px;
box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

.welcome-card h1{
font-size:32px;
margin-bottom:10px;
}

.welcome-card p{
font-size:15px;
opacity:0.9;
}

/* STATS */

.stats{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:20px;
margin-bottom:30px;
}

.stat-card{
background:white;
padding:25px;
border-radius:18px;
box-shadow:0 6px 18px rgba(0,0,0,0.05);
transition:0.3s;
}

.stat-card:hover{
transform:translateY(-5px);
}

.stat-top{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:18px;
}

.stat-top i{
font-size:26px;
color:#10b981;
}

.stat-card h2{
font-size:28px;
color:#064e3b;
margin-bottom:8px;
}

.stat-card p{
color:#6b7280;
font-size:14px;
}

/* ACTION CARDS */

.action-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
gap:25px;
}

.action-card{
background:white;
padding:28px;
border-radius:20px;
box-shadow:0 8px 25px rgba(0,0,0,0.05);
transition:0.3s;
}

.action-card:hover{
transform:translateY(-6px);
}

.action-card i{
font-size:40px;
color:#10b981;
margin-bottom:20px;
}

.action-card h3{
margin-bottom:12px;
color:#064e3b;
}

.action-card p{
font-size:14px;
color:#6b7280;
margin-bottom:22px;
line-height:1.6;
}

.action-card a{
display:inline-block;
padding:12px 20px;
background:#064e3b;
color:white;
text-decoration:none;
border-radius:10px;
font-size:14px;
font-weight:600;
transition:0.3s;
}

.action-card a:hover{
background:#10b981;
}

/* CHAT BUTTON */

#chatToggle{
position:fixed;
bottom:25px;
right:25px;
width:65px;
height:65px;
background:#064e3b;
color:white;
border-radius:50%;
display:flex;
justify-content:center;
align-items:center;
font-size:28px;
cursor:pointer;
box-shadow:0 10px 25px rgba(0,0,0,0.2);
z-index:999;
transition:0.3s;
}

#chatToggle:hover{
background:#10b981;
transform:scale(1.08);
}

/* CHAT BOX */

.chat-container{
width:360px;
height:520px;
background:white;
position:fixed;
bottom:100px;
right:25px;
border-radius:20px;
overflow:hidden;
display:none;
flex-direction:column;
box-shadow:0 12px 35px rgba(0,0,0,0.15);
z-index:999;
}

.chat-header{
background:#064e3b;
color:white;
padding:18px;
font-weight:600;
display:flex;
justify-content:space-between;
align-items:center;
}

.chat-body{
flex:1;
padding:18px;
overflow-y:auto;
background:#f9fafb;
}

.bot-message,
.user-message{
padding:12px 15px;
margin-bottom:12px;
border-radius:15px;
max-width:80%;
font-size:14px;
line-height:1.5;
}

.bot-message{
background:white;
border:1px solid #e5e7eb;
}

.user-message{
background:#10b981;
color:white;
margin-left:auto;
}

.quick-buttons{
padding:12px;
display:flex;
flex-wrap:wrap;
gap:10px;
background:white;
border-top:1px solid #eee;
}

.quick-buttons button{
padding:10px 14px;
border:none;
background:#ecfdf5;
color:#064e3b;
border-radius:20px;
cursor:pointer;
font-size:13px;
font-weight:600;
}

.chat-input{
display:flex;
padding:15px;
background:white;
border-top:1px solid #eee;
}

.chat-input input{
flex:1;
padding:12px;
border:1px solid #ddd;
border-radius:10px;
outline:none;
}

.chat-input button{
padding:12px 18px;
margin-left:10px;
border:none;
background:#064e3b;
color:white;
border-radius:10px;
cursor:pointer;
font-weight:600;
}

/* TOPBAR RIGHT SECTION */

.topbar-right{
    display: flex;
    align-items: center;
    gap: 20px;
}


/* NOTIFICATION BELL */

.notification{
    position: relative;
    color: #064e3b;
    font-size: 22px;
    text-decoration: none;
    transition: 0.3s;
}

.notification:hover{
    color: #10b981;
    transform: scale(1.1);
}


/* RED NOTIFICATION BADGE */

.notification-count{
    position: absolute;
    top: -8px;
    right: -10px;
    background: #ef4444;
    color: white;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    font-size: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: 600;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}


/* USER BOX IMPROVEMENT */

.user-box{
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
    color: #064e3b;
}

.user-box i{
    font-size: 24px;
    color: #10b981;
}

/* RESPONSIVE */

@media(max-width:900px){

.sidebar{
width:100%;
height:auto;
position:relative;
}

.main{
margin-left:0;
}

body{
display:block;
}

}

@media(max-width:500px){

.topbar{
padding:0 15px;
}

.welcome-card h1{
font-size:24px;
}

.chat-container{
width:95%;
right:2.5%;
}

}

/* HAMBURGER */

.menu-toggle{

display:none;

font-size:24px;

cursor:pointer;

color:#064e3b;

margin-right:15px;

}

.sidebar{

transition:.35s;

}

@media(max-width:768px){

.menu-toggle{

display:block;

}


.sidebar{

position:fixed;

left:-260px;

top:0;

width:250px;

height:100vh;

z-index:999;

transition:.35s;

}


.sidebar.active{

left:0;

}


.main-content{

width:100%;

margin-left:0;

}


.topbar{

padding:15px;

}

}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar" id="sidebar">

<div class="logo">
<img src="logo.jpeg" width="85" style="boder-radius: 50%">
<h2>SUG Portal</h2>
</div>

<a href="dashboard.php" class="active">
<i class="fa-solid fa-house"></i>
Dashboard
</a>

<a href="profile.php">
<i class="fa-solid fa-user"></i>
Profile
</a>

<a href="payment.php">
<i class="fa-solid fa-credit-card"></i>
Payments
</a>

<a href="payment_history.php">
<i class="fa-solid fa-clock-rotate-left"></i>
Payment History
</a>

<a href="generate_receipt.php">
<i class="fa-solid fa-file-invoice"></i>
Receipt
</a>
<a href="timetable.php">
<i class="fa-solid fa-clock "></i>
Timetable
</a>
<a href="calendar.php">
<i class="fas fa-calendar-alt"></i>
School Calendar
</a>
<a href="complaints.php">
    <i class="fas fa-comment-dots"></i>
    Complaints/Feedback
</a>
<a href="logout.php">
<i class="fa-solid fa-right-from-bracket"></i>
Logout
</a>



</div>


<!-- MAIN -->

<div class="main">

    <div class="topbar">

<div class="menu-toggle" id="menuToggle">

<i class="fas fa-bars"></i>

</div>



<div class="topbar-right">


</div>

</div>

<!-- TOPBAR -->

<div class="topbar">

<h3>Student Dashboard</h3>

<div class="topbar-right">

<!-- Notification Bell -->
<a href="notifications.php" class="notification">

<i class="fa-solid fa-bell"></i>

<?php if($unread > 0){ ?>

<span class="notification-count">
<?php echo $unread; ?>
</span>

<?php } ?>

</a>


<div class="user-box">

<i class="fa-solid fa-circle-user"></i>

<?php echo $student_name; ?>

</div>

</div>

</div>

<!-- CONTENT -->

<div class="content">

<!-- WELCOME -->

<div class="welcome-card">

<h1>Welcome, <?php echo $student_name; ?> </h1>

<p>
Manage your SUG dues, receipts, profile and payment history easily from your dashboard.
</p>

</div>

<!-- STATS -->

<div class="stats">

<div class="stat-card">

<div class="stat-top">
<h4>Total Dues</h4>
<i class="fa-solid fa-wallet"></i>
</div>

<h2>₦5,000</h2>

<p>SUG Payment Fee</p>

</div>

<div class="stat-card">

<div class="stat-top">
<h4>Payment Status</h4>
<i class="fa-solid fa-circle-check"></i>
</div>

<h2>Pending</h2>

<p>Awaiting Payment</p>

</div>

<div class="stat-card">

<div class="stat-top">
<h4>Support</h4>
<i class="fa-solid fa-headset"></i>
</div>

<h2>24/7</h2>

<p>Chat Assistance Available</p>

</div>

</div>

<!-- ACTIONS -->

<div class="action-grid">

<div class="action-card">

<i class="fa-solid fa-credit-card"></i>

<h3>Pay SUG Dues</h3>

<p>
Pay your SUG dues securely online using Paystack payment gateway.
</p>

<a href="payment.php">Make Payment</a>

</div>

<div class="action-card">

<i class="fa-solid fa-user"></i>

<h3>My Profile</h3>

<p>
View and manage your student information and profile picture.
</p>

<a href="profile.php">View Profile</a>

</div>

    <div class="action-card">

    <i class="fa-solid fa-receipt"></i>

    <h3>Payment Receipt</h3>

    <p>
    Download and print your official SUG payment receipt instantly.
    </p>

    <a href="generate_receipt.php">Download Receipt</a>

    </div>

<div class="action-card">

<i class="fa-solid fa-clock-rotate-left"></i>
<h3>Payment History</h3>
<p>Track all your previous SUG payment transactions and records.</p>

<a href="payment_history.php">View History</a>

</div>

    <div class="action-card">

    <i class="fas fa-calendar-alt"></i>
    <h3>School Calendar </h3>

    <p>View and download the latest school calendar</p>

    <a href="calendar.php">View Calendar</a>

    </div>

    <div class="action-card">

    <i class="fas fa-clock"></i>

    <h3>Lecture Timetable</h3>

    <p>View and download the latest timetable</p>

    <a href="timetable.php">View Timetable</a>

    </div>

    <div class="action-card">
    <i class="fas fa-comment-dots"></i>
    <h3>Complaint & Feedback</h3>
    <p>Submit complaints, suggestions and feedback directly to the SUG administration.</p>
    <a href="complaints.php" > Open</a>

</div>

</div>

</div>

</div>



<!-- CHAT ICON -->

<div id="chatToggle">
<i class="fa-solid fa-comments"></i>
</div>

<!-- CHAT BOX -->

<div class="chat-container" id="chatContainer">

<div class="chat-header">
🎓 SUG Support
<span id="closeChat" style="cursor:pointer;">
<i class="fa-solid fa-xmark"></i>
</span>
</div>

<div class="chat-body" id="chatBox">

<div class="bot-message">
Hello <?php echo $student_name; ?> 👋 <br>
How can I assist you today?
</div>

</div>

<div class="quick-buttons">
<button onclick="quickMessage('What is the SUG dues?')">Dues</button>
<button onclick="quickMessage('Check my payment status')">Status</button>
<button onclick="quickMessage('How do I pay my SUG dues')">Pay</button>
<button onclick="quickMessage('Download receipt')">Receipt</button>
</div>

<div class="chat-input">

<input type="text" id="userInput" placeholder="Type message...">

<button onclick="sendMessage()">
<i class="fa-solid fa-paper-plane"></i>
</button>

</div>

</div>

<script>

/* OPEN CHAT */
document.getElementById("chatToggle").onclick=function(){
document.getElementById("chatContainer").style.display="flex";
}

/* CLOSE CHAT */
document.getElementById("closeChat").onclick=function(){
document.getElementById("chatContainer").style.display="none";
}

/* SEND MESSAGE */

function sendMessage(){

let input=document.getElementById("userInput");
let message=input.value.trim();

if(message==="") return;

let chatBox=document.getElementById("chatBox");

let user=document.createElement("div");
user.className="user-message";
user.innerText=message;

chatBox.appendChild(user);

input.value="";

let typing=document.createElement("div");
typing.className="bot-message";
typing.innerText="Typing...";

chatBox.appendChild(typing);

fetch("chatrespond.php",{
method:"POST",
headers:{
"Content-Type":"application/x-www-form-urlencoded"
},
body:"message="+encodeURIComponent(message)
})

.then(res=>res.text())

.then(data=>{

typing.remove();

let bot=document.createElement("div");
bot.className="bot-message";
bot.innerHTML=data;

chatBox.appendChild(bot);

chatBox.scrollTop=chatBox.scrollHeight;

});

}

/* ENTER KEY */

document.getElementById("userInput")
.addEventListener("keypress",function(e){

if(e.key==="Enter"){
sendMessage();
}

});

/* QUICK BUTTON */

function quickMessage(text){

document.getElementById("userInput").value=text;

sendMessage();

}
// const menuToggle = document.getElementById("menuToggle");

// const sidebar = document.getElementById("sidebar");

// menuToggle.addEventListener("click", function(){

//     sidebar.classList.toggle("active");

// });

const menuToggle = document.getElementById("menuToggle");
const sidebar = document.getElementById("sidebar");
const overlay = document.getElementById("overlay");

menuToggle.addEventListener("click", function () {
    sidebar.classList.toggle("active");
    overlay.classList.toggle("active");
});

overlay.addEventListener("click", function () {
    sidebar.classList.remove("active");
    overlay.classList.remove("active");
});
</script>
</body>
</html>