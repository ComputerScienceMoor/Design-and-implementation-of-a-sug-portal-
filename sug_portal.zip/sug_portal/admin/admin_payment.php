<?php
session_start();

include("../db.php");

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';

$query = "
SELECT
payments.*,
students.category,
students.department
FROM payments
INNER JOIN students
ON payments.student_id = students.id
WHERE 1
";

if(!empty($search)){
    $query .= " AND (
        payments.student_name LIKE '%$search%'
        OR payments.matric_no LIKE '%$search%'
    )";
}

if(!empty($category)){
    $query .= " AND students.category='$category'";
}

$query .= " ORDER BY payments.id DESC";

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    /* PAYMENT TABLE */

.table-container{
background:white;
padding:25px;
border-radius:20px;
margin-top:30px;
box-shadow:0 8px 25px rgba(0,0,0,0.05);
overflow-x:auto;
}

.section-title{
margin-bottom:20px;
}

.section-title h2{
color:#064e3b;
}

.search-box{
display:flex;
gap:12px;
margin-bottom:20px;
flex-wrap:wrap;
}

.search-box input,
.search-box select{
padding:12px;
border:1px solid #ddd;
border-radius:10px;
outline:none;
}

.search-box button{
padding:12px 18px;
border:none;
background:#064e3b;
color:white;
border-radius:10px;
cursor:pointer;
}

table{
width:100%;
border-collapse:collapse;
}

table th{
background:#064e3b;
color:white;
padding:15px;
text-align:left;
}

table td{
padding:15px;
border-bottom:1px solid #eee;
}

.paid{
background:#dcfce7;
color:#15803d;
padding:6px 12px;
border-radius:20px;
font-size:12px;
font-weight:600;
}

.approve-btn{
padding:8px 12px;
border:none;
background:#10b981;
color:white;
border-radius:8px;
cursor:pointer;
margin-right:5px;
}

.reject-btn{
padding:8px 12px;
border:none;
background:#ef4444;
color:white;
border-radius:8px;
cursor:pointer;
}
</style>
<body>

<div class="table-container">

<div class="section-title">
<h2>Payment Management</h2>
</div>

<!-- Revenue Cards -->

<?php

$totalRevenueQuery = $conn->query("
SELECT SUM(amount) AS total_revenue
FROM payments
WHERE verified = 1
");

$totalRevenue = $totalRevenueQuery->fetch_assoc();

$totalRevenue = $totalRevenue['total_revenue'] ?? 0;

$totalPaymentsQuery = $conn->query("
SELECT COUNT(*) AS total_payments
FROM payments
");

$totalPayments = $totalPaymentsQuery->fetch_assoc();

?>

<div style="display:flex;gap:20px;margin-bottom:25px;flex-wrap:wrap;">

<div style="background:#064e3b;color:white;padding:20px;border-radius:15px;min-width:220px;">
<h4>Total Revenue</h4>
<h2>₦<?php echo number_format($totalRevenue); ?></h2>
</div>

<div style="background:#10b981;color:white;padding:20px;border-radius:15px;min-width:220px;">
<h4>Total Payments</h4>
<h2><?php echo $totalPayments['total_payments']; ?></h2>
</div>

</div>

<!-- Search -->

<form method="GET" class="search-box">

<input
type="text"
name="search"
placeholder="Search student..."
value="<?php echo htmlspecialchars($search); ?>">

<select name="category">

<option value="">All Categories</option>

<option value="fresher"
<?php if($category=="fresher") echo "selected"; ?>>
Fresher
</option>

<option value="staylite"
<?php if($category=="staylite") echo "selected"; ?>>
Staylite
</option>

</select>

<button type="submit">Search</button>

</form>

<!-- Table -->

<table>

<tr>
<th>Student</th>
<th>Matric No</th>
<th>Category</th>
<th>Department</th>
<th>Amount</th>
<th>Status</th>
<th>Reference</th>
<th>Date</th>
</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td><?php echo $row['student_name']; ?></td>

<td><?php echo $row['matric_no']; ?></td>

<td><?php echo ucfirst($row['category']); ?></td>

<td><?php echo $row['department']; ?></td>

<td>₦<?php echo number_format($row['amount']); ?></td>

<td>

<?php if($row['verified'] == 1){ ?>

<span class="paid">Verified</span>

<?php } else { ?>

<span style="
background:#fee2e2;
color:#dc2626;
padding:6px 12px;
border-radius:20px;
font-size:12px;
font-weight:600;
">
Pending
</span>

<?php } ?>

</td>

<td><?php echo $row['reference']; ?></td>

<td><?php echo $row['payment_date']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>
