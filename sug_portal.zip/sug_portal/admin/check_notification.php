<?php
include("../db.php");

$result = $conn->query("SELECT COUNT(*) as total FROM payments WHERE status='success'");
$row = $result->fetch_assoc();

echo $row['total'];

<script>
setInterval(() => {
    fetch('check_notifications.php')
    .then(res => res.text())
    .then(data => {
        document.getElementById("notification").innerText = "Payments: " + data;
    });
}, 5000);
</script>