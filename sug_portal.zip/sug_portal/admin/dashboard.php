<?php
session_start();
include("../db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit();
}

// STATS
$total_students = $conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total'];
$total_payments = $conn->query("SELECT COUNT(*) as total FROM payments")->fetch_assoc()['total'];
$total_revenue = $conn->query("SELECT SUM(amount) as total FROM payments WHERE status='success'")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- GOOGLE FONT -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/admin-dashboard.css">
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
<div class="logo"><i class="fa-solid fa-graduation-cap"></i> Admin Panel</div>

<div class="menu">
<a href="#" class="active"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
<a href="#students"><i class="fa-solid fa-users"></i> Students</a>
<a href="admin_payment.php"><i class="fa-solid fa-credit-card"></i> Payments</a>
<a href="analytics.php"><i class="fa-solid fa-chart-line"></i> Analytics</a>
<a href="admin_timetable.php"><i class="fas fa-clock"></i>Timetable</a>
<a href="admin_calendar.php"><i class="fas fa-calendar-alt"></i>School Calendar</a>
<a href="admin_complaints.php"><i class="fas fa-comments"></i>Complaints</a>
<a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>

</li>
</div>
</div>

<!-- TOPBAR -->
<div class="topbar">
    
<h3>Dashboard Overview</h3>
<div class="user"><i class="fa-solid fa-user-circle"></i> Admin</div>
<!-- <div id="notification" style="color:red;font-weight:bold;"></div> -->
</div>

<!-- CONTENT -->
<div class="content">

<!-- CARDS -->
<div class="cards">

<div class="card">
<i class="fa-solid fa-users"></i>
<h4>Total Students</h4>
<h2><?php echo $total_students; ?></h2>
</div>

<div class="card">
<i class="fa-solid fa-money-bill-wave"></i>
<h4>Total Payments</h4>
<h2><?php echo $total_payments; ?></h2>
</div>

<div class="card">
<i class="fa-solid fa-coins"></i>
<h4>Total Revenue</h4>
<h2>₦<?php echo number_format($total_revenue ?? 0); ?></h2>
</div>

</div>

<input type="text" id="searchInput" placeholder="Search students..." style="padding:10px;width:100%;margin-bottom:10px;">

<!-- STUDENTS -->
<div class="table-box" id="studentsTable">
<h3>Students</h3>

<table>
<tr>
<th>Name</th>
<th>Matric</th>
<th>Email</th>
<th>Department</th>
</tr>

<?php

$students = $conn->query("SELECT * FROM students");
// $limit = 5;
// $page = isset($_GET['page']) ? $_GET['page'] : 1;
// $start = ($page - 1) * $limit;

// $students = $conn->query("SELECT * FROM students LIMIT $start, $limit");

while($row = $students->fetch_assoc()){
?>
<tr>
<td><?php echo $row['full_name']; ?></td>
<td><?php echo $row['matric_no']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['department']; ?></td>
</tr>
<?php } ?>

<!-- <?php
$total = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'];
$pages = ceil($total / $limit);

for($i=1; $i<=$pages; $i++){
    echo "<a href='?page=$i' style='margin:5px;'>$i</a>";
}
?> -->
</table>
</div>

<!-- PAYMENTS -->
<div class="table-box" id="payments">
<h3>Payments</h3>

<table>
<tr>
<th>Student ID</th>
<th>Amount</th>
<th>Reference</th>
<th>Status</th>
</tr>

<?php
$payments = $conn->query("SELECT * FROM payments");

while($row = $payments->fetch_assoc()){
?>
<tr>
<td><?php echo $row['student_id']; ?></td>
<td>₦<?php echo number_format($row['amount']); ?></td>
<td><?php echo $row['reference']; ?></td>
<td class="<?php echo ($row['status'] == 'success') ? 'success' : 'pending'; ?>">
<?php echo ucfirst($row['status']); ?>
</td>
</tr>
<?php } ?>

</table>
</div>

</div>

<script>
document.getElementById("searchInput").addEventListener("keyup", function() {
    let value = this.value.toLowerCase();
    let rows = document.querySelectorAll("#studentsTable tr");

    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(value) ? "" : "none";
    });
});
</script>

</body>
</html>