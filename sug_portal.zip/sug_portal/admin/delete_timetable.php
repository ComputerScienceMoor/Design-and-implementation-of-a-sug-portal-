<?php
include("../db.php");

$id = intval($_GET['id']);

$stmt = $conn->prepare(
"SELECT file_name FROM timetable WHERE id=?"
);

$stmt->bind_param("i",$id);
$stmt->execute();

$result = $stmt->get_result();
$file = $result->fetch_assoc();

if($file){

$path = "../uploads/timetable/".$file['file_name'];

if(file_exists($path)){
unlink($path);
}

$delete = $conn->prepare(
"DELETE FROM timetable WHERE id=?"
);

$delete->bind_param("i",$id);
$delete->execute();
}

header("Location: admin_timetable.php");
exit();
?>