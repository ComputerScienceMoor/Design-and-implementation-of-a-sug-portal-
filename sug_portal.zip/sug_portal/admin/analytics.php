<?php
session_start();
include("../db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit();
}

// FETCH DATA
$data = array_fill(1, 12, 0);

$query = $conn->query("
SELECT MONTH(created_at) as month, SUM(amount) as total 
FROM payments 
WHERE status='success'
GROUP BY MONTH(created_at)
");

while($row = $query->fetch_assoc()){
    $data[(int)$row['month']] = (int)$row['total'];
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Analytics</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- CHART -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- FONT -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

<style>

body{
margin:0;
font-family:'Inter',sans-serif;
background:#f1f5f9;
}

/* SIDEBAR */
.sidebar{
width:250px;
height:100vh;
background:#064e3b;
position:fixed;
color:white;
padding:20px;
}

.sidebar a{
display:block;
color:white;
text-decoration:none;
padding:12px;
margin-bottom:10px;
border-radius:8px;
}

.sidebar a:hover{
background:#10b981;
}

/* CONTENT */
.content{
margin-left:250px;
padding:25px;
}

/* CARD */
.card{
background:white;
padding:20px;
border-radius:12px;
box-shadow:0 4px 10px rgba(0,0,0,0.05);
margin-bottom:20px;
}

/* RESPONSIVE */
@media(max-width:768px){
.sidebar{
width:100%;
height:auto;
position:relative;
}
.content{
margin-left:0;
}
}

</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
<h2><i class="fa-solid fa-chart-line"></i> Admin</h2>
<a href="../admin/dashboard.php"><i class="fa-solid fa-home"></i> Dashboard</a>
<a href="admin_payment.php"><i class="fa-solid fa-credit-card"></i> Payments</a>
<a href="analytics.php"><i class="fa-solid fa-chart-line"></i> Analytics</a>
<a href="admin_timetable.php"><i class="fas fa-clock"></i>Timetable</a>
<a href="admin_calendar.php"><i class="fas fa-calendar-alt"></i>School Calendar</a>
<a href="admin_complaints.php"><i class="fas fa-comments"></i>Complaints</a>
<a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>

<!-- CONTENT -->
<div class="content">

<h2>Analytics Overview</h2>

<div class="card">
<canvas id="chart"></canvas>
</div>

</div>

<script>
const ctx = document.getElementById('chart');

new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
        datasets: [{
            label: 'Monthly Revenue',
            data: <?php echo json_encode(array_values($data)); ?>,
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }]
    }
});
</script>

</body>
</html>