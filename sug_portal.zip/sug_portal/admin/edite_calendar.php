<?php
include("../db.php");

$id = $_GET['id'];

$stmt = $conn->prepare(
"SELECT * FROM school_calendar WHERE id=?"
);

$stmt->bind_param("i",$id);
$stmt->execute();

$result = $stmt->get_result();
$row = $result->fetch_assoc();

if(isset($_POST['update'])){

$title = trim($_POST['title']);

$update = $conn->prepare(
"UPDATE school_calendar SET title=? WHERE id=?"
);

$update->bind_param(
"si",
$title,
$id
);

$update->execute();

header("Location: admin_calendar.php");
exit();

}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Calendar</title>

<style>

body{
font-family:Poppins,sans-serif;
background:#f1f5f9;
padding:40px;
}

.card{
background:white;
padding:30px;
max-width:600px;
margin:auto;
border-radius:20px;
box-shadow:0 8px 20px rgba(0,0,0,.08);
}

input{
width:100%;
padding:15px;
border:1px solid #ddd;
border-radius:10px;
margin-bottom:20px;
}

button{
background:#059669;
color:white;
border:none;
padding:15px 20px;
border-radius:10px;
cursor:pointer;
}

</style>

</head>

<body>

<div class="card">

<h2>Edit Calendar Title</h2>

<form method="POST">

<input
type="text"
name="title"
value="<?php echo htmlspecialchars($row['title']); ?>"
required>

<button name="update">
Update Calendar
</button>

</form>

</div>

</body>
</html>