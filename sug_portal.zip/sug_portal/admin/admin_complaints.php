<?php
session_start();
include("../db.php");

/*
---------------------------------
UPDATE COMPLAINT
---------------------------------
*/

if(isset($_POST['update'])){

    $id = $_POST['id'];

    $status = $_POST['status'];

    $reply = trim($_POST['reply']);


    $stmt = $conn->prepare("
    UPDATE complaints
    SET status=?, admin_reply=?
    WHERE id=?
    ");

    $stmt->bind_param(
        "ssi",
        $status,
        $reply,
        $id
    );

    if($stmt->execute()){

        /*
        Create notification for students
        */

        $title = "Complaint Update";

        $message = "Your complaint has been reviewed by the SUG administration. Status: ".$status;

        $student_id = $row['student_id'];

        $notify->bind_param(
            "ss",
            $title,
            $message
        );

        $notify->execute();

    }

}


/*
---------------------------------
DELETE COMPLAINT
---------------------------------
*/

if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    $stmt = $conn->prepare("
    DELETE FROM complaints
    WHERE id=?
    ");

    $stmt->bind_param(
        "i",
        $id
    );

    $stmt->execute();

}


/*
---------------------------------
SEARCH & FILTER
---------------------------------
*/

$search = $_GET['search'] ?? "";

$status = $_GET['status'] ?? "";


/*
---------------------------------
STATISTICS
---------------------------------
*/

$total = $conn->query("
SELECT COUNT(*) AS total
FROM complaints
")->fetch_assoc();


$pending = $conn->query("
SELECT COUNT(*) AS total
FROM complaints
WHERE status='Pending'
")->fetch_assoc();


$progress = $conn->query("
SELECT COUNT(*) AS total
FROM complaints
WHERE status='In Progress'
")->fetch_assoc();


$resolved = $conn->query("
SELECT COUNT(*) AS total
FROM complaints
WHERE status='Resolved'
")->fetch_assoc();


/*
---------------------------------
FETCH COMPLAINTS
---------------------------------
*/

$query = "
SELECT 
complaints.*,
students.matric_no,
students.department,
students.category

FROM complaints

INNER JOIN students
ON complaints.student_id = students.id

WHERE 1
";


if(!empty($search)){

    $query .= "
    AND (
        complaints.student_name LIKE '%$search%'
        OR students.matric_no LIKE '%$search%'
        OR complaints.subject LIKE '%$search%'
    )
    ";

}


if(!empty($status)){

    $query .= "
    AND complaints.status='$status'
    ";

}


$query .= "
ORDER BY complaints.id DESC
";


$result = $conn->query($query);

?>  

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" 
content="width=device-width, initial-scale=1.0">

<title>
Admin Complaint Management
</title>


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<style>

/* GLOBAL */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins', sans-serif;
}


body{
    background:#f1f5f9;
    padding:30px;
}


/* PAGE HEADER */

.page-header{
    background:linear-gradient(135deg,#064e3b,#10b981);
    color:white;
    padding:30px;
    border-radius:20px;
    margin-bottom:25px;
    box-shadow:0 10px 30px rgba(0,0,0,.15);
}


.page-header h1{
    font-size:30px;
    margin-bottom:8px;
}


.page-header p{
    opacity:.9;
}


/* ANALYTICS */

.analytics{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:20px;
    margin-bottom:25px;
}


.card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 8px 25px rgba(0,0,0,.06);
    transition:.3s;
}


.card:hover{
    transform:translateY(-5px);
}


.card-icon{
    width:55px;
    height:55px;
    background:#ecfdf5;
    color:#059669;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
    margin-bottom:15px;
}


.card h2{
    color:#064e3b;
    font-size:30px;
}


.card p{
    color:#64748b;
    margin-top:5px;
}


/* SEARCH AREA */

.search-card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 8px 25px rgba(0,0,0,.06);
    margin-bottom:25px;
}


.search-box{
    display:flex;
    gap:15px;
    flex-wrap:wrap;
}


.search-box input,
.search-box select{
    flex:1;
    min-width:220px;
    padding:14px;
    border:1px solid #ddd;
    border-radius:12px;
    outline:none;
    transition:.3s;
}


.search-box input:focus,
.search-box select:focus{
    border-color:#10b981;
    box-shadow:0 0 0 3px rgba(16,185,129,.15);
}


.search-btn{
    background:#059669;
    color:white;
    border:none;
    padding:14px 20px;
    border-radius:12px;
    cursor:pointer;
    font-weight:600;
}


.search-btn:hover{
    background:#047857;
}


/* TABLE CARD */

.table-card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 8px 25px rgba(0,0,0,.06);
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}


table th{
    background:#064e3b;
    color:white;
    padding:15px;
    text-align:left;
    font-size:14px;
}


table td{
    padding:15px;
    border-bottom:1px solid #eee;
    vertical-align:top;
    font-size:14px;
}


table tr:hover{
    background:#f8fafc;
}


/* STATUS BADGES */

.badge{
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}


.pending{
    background:#fef3c7;
    color:#92400e;
}


.progress{
    background:#dbeafe;
    color:#1d4ed8;
}


.resolved{
    background:#dcfce7;
    color:#166534;
}


/* FORM CONTROLS */

.action-form select,
.action-form textarea{
    width:100%;
    margin-top:8px;
    padding:10px;
    border:1px solid #ddd;
    border-radius:10px;
    outline:none;
}


.action-form textarea{
    height:80px;
    resize:none;
}


/* BUTTONS */

.update-btn{
    background:#059669;
    color:white;
    border:none;
    padding:10px 15px;
    border-radius:10px;
    cursor:pointer;
    margin-top:10px;
}


.update-btn:hover{
    background:#047857;
}


.delete-btn{
    background:#dc2626;
    color:white;
    text-decoration:none;
    padding:10px 15px;
    border-radius:10px;
    display:inline-block;
    margin-top:8px;
}


.delete-btn:hover{
    background:#b91c1c;
}


@media(max-width:768px){

table{
    font-size:12px;
}

table th,
table td{
    padding:10px;
}

}


/* RESPONSIVE */

@media(max-width:1000px){

.analytics{
    grid-template-columns:repeat(2,1fr);
}

}


@media(max-width:600px){

body{
    padding:15px;
}


.analytics{
    grid-template-columns:1fr;
}


.page-header h1{
    font-size:22px;
}


.search-box{
    flex-direction:column;
}

}

</style>

</head>


<body>


<!-- PAGE HEADER -->

<div class="page-header">

<h1>
<i class="fas fa-comments"></i>
 Complaint Management
</h1>

<p>
View, manage and respond to student complaints and feedback.
</p>

</div>



<!-- ANALYTICS CARDS -->

<div class="analytics">


<div class="card">

<div class="card-icon">
<i class="fas fa-list"></i>
</div>

<h2>
<?php echo $total['total']; ?>
</h2>

<p>Total Complaints</p>

</div>



<div class="card">

<div class="card-icon">
<i class="fas fa-clock"></i>
</div>

<h2>
<?php echo $pending['total']; ?>
</h2>

<p>Pending</p>

</div>



<div class="card">

<div class="card-icon">
<i class="fas fa-spinner"></i>
</div>

<h2>
<?php echo $progress['total']; ?>
</h2>

<p>In Progress</p>

</div>



<div class="card">

<div class="card-icon">
<i class="fas fa-check-circle"></i>
</div>

<h2>
<?php echo $resolved['total']; ?>
</h2>

<p>Resolved</p>

</div>


</div>



<!-- SEARCH & FILTER -->

<div class="search-card">


<form method="GET" class="search-box">


<input 
type="text"
name="search"
placeholder="Search by student, matric or subject..."
value="<?php echo htmlspecialchars($search); ?>">


<select name="status">


<option value="">
All Status
</option>


<option value="Pending"
<?php if($status=="Pending") echo "selected"; ?>>
Pending
</option>


<option value="In Progress"
<?php if($status=="In Progress") echo "selected"; ?>>
In Progress
</option>


<option value="Resolved"
<?php if($status=="Resolved") echo "selected"; ?>>
Resolved
</option>


</select>


<button 
class="search-btn">

<i class="fas fa-search"></i>
 Search

</button>


</form>


</div>


<!-- TABLE WILL START IN PART 3 -->

<div class="table-card">
    <h2 style="color:#064e3b; margin-bottom:20px;">
<i class="fas fa-table"></i>
 Student Complaints
</h2>


<table>



<tr>

<th>Student</th>
<th>Matric No</th>
<th>Department</th>
<th>Category</th>
<th>Complaint</th>
<th>Status</th>
<th>Action</th>

</tr>


<?php

if($result->num_rows > 0){

while($row = $result->fetch_assoc()){


$class = "pending";


if($row['status']=="In Progress"){
    $class = "progress";
}


if($row['status']=="Resolved"){
    $class = "resolved";
}

?>


<tr>


<td>
<b>
<?php echo htmlspecialchars($row['student_name']); ?>
</b>
</td>


<td>
<?php echo htmlspecialchars($row['matric_no']); ?>
</td>


<td>
<?php echo htmlspecialchars($row['department']); ?>
</td>


<td>
<?php echo ucfirst($row['category']); ?>
</td>


<td>

<b>
<?php echo htmlspecialchars($row['subject']); ?>
</b>

<br><br>

<?php echo nl2br(htmlspecialchars($row['message'])); ?>

</td>


<td>

<span class="badge <?php echo $class; ?>">

<?php echo $row['status']; ?>

</span>

</td>


<td>


<form method="POST" class="action-form">


<input 
type="hidden"
name="id"
value="<?php echo $row['id']; ?>">


<select name="status">


<option value="Pending"
<?php if($row['status']=="Pending") echo "selected"; ?>>
Pending
</option>


<option value="In Progress"
<?php if($row['status']=="In Progress") echo "selected"; ?>>
In Progress
</option>


<option value="Resolved"
<?php if($row['status']=="Resolved") echo "selected"; ?>>
Resolved
</option>


</select>


<textarea 
name="reply"
placeholder="Write admin response..."><?php 
echo htmlspecialchars($row['admin_reply']); 
?></textarea>


<button 
type="submit"
name="update"
class="update-btn">

<i class="fas fa-paper-plane"></i>
 Update

</button>


<br>


<a 
class="delete-btn"
href="?delete=<?php echo $row['id']; ?>"
onclick="return confirm('Are you sure you want to delete this complaint?')">

<i class="fas fa-trash"></i>
 Delete

</a>


</form>


</td>


</tr>


<?php

}

}else{

?>


<tr>

<td colspan="7" style="text-align:center; padding:30px;">

<i class="fas fa-folder-open"
style="font-size:50px; color:#10b981;"></i>

<br><br>

No complaints found.

</td>

</tr>


<?php

}

?>


</table>


</div>


</body>

</html>