<?php
session_start();
require_once("../db.php");

$error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    // ✅ Safe access (no undefined error)
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // ✅ Check if fields are empty
    if(empty($username) || empty($password)){
        $error = "Please fill all fields";
    } else {

        $stmt = $conn->prepare("SELECT * FROM admins WHERE username=?");

        if(!$stmt){
            die("SQL Error: " . $conn->error);
        }

        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin = $result->fetch_assoc();

        if($admin && password_verify($password, $admin['PASSWORD'])){
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid username or password!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<style>
body{
background:#f4f6f9;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
font-family:Segoe UI;
}
.box{
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 5px 20px rgba(0,0,0,0.1);
width:300px;
}
input, button{
width:100%;
padding:10px;
margin:10px 0;
}
button{
background:#0b5d3b;
color:white;
border:none;
}
.error{color:red;}
</style>
</head>

<body>

<div class="box">
<h2>Admin Login</h2>

<form method="POST">
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Login</button>
</form>

<p class="error"><?php echo $error; ?></p>

</div>

</body>
</html>