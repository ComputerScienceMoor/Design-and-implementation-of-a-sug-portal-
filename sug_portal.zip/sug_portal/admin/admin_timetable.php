<?php
session_start();
include("../db.php");

$message = "";

/* UPLOAD TIMETABLE */

if(isset($_POST['upload'])){

    $title = trim($_POST['title']);

    if(isset($_FILES['file']) && $_FILES['file']['error'] == 0){

        $fileName = time() . "_" . basename($_FILES['file']['name']);
        $target = "../uploads/timetable/" . $fileName;

        $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if($extension != "pdf"){

            $message = "<div class='alert error'>Only PDF files are allowed.</div>";

        }else{

            if(move_uploaded_file($_FILES['file']['tmp_name'], $target)){

              $stmt = $conn->prepare("
                INSERT INTO timetable(title,file_name)
                VALUES(?,?)
                ");

                $stmt->bind_param("ss",$title,$fileName);
                $stmt->execute();

                /* CREATE NOTIFICATION */

                $conn->query("
                INSERT INTO notifications(title,message)
                VALUES(
                'New Timetable Uploaded',
                'Login to view the latest timetable.'
                )
                ");

                $message = "<div class='alert success'>
                Timetable uploaded successfully.
                </div>";
            }else{

                $message = "<div class='alert error'>Upload failed.</div>";

            }
        }
    }
}

/* CURRENT TIMETABLE */

$current = $conn->query("
SELECT *
FROM timetable
ORDER BY id DESC
LIMIT 1
");

$currentFile = $current->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Timetable Management</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;
}

body{
background:#f1f5f9;
padding:30px;
}

/* PAGE HEADER */

.page-title{
margin-bottom:25px;
}

.page-title h1{
color:#064e3b;
font-size:28px;
margin-bottom:8px;
}

.page-title p{
color:#64748b;
}

/* CARD */

.card{
background:#fff;
padding:25px;
border-radius:20px;
box-shadow:0 10px 30px rgba(0,0,0,.05);
margin-bottom:25px;
}

/* ALERT */

.alert{
padding:15px;
border-radius:10px;
margin-bottom:20px;
font-weight:500;
}

.success{
background:#dcfce7;
color:#166534;
}

.error{
background:#fee2e2;
color:#991b1b;
}

/* FORM */

.form-group{
margin-bottom:20px;
}

.form-group input[type=text]{
width:100%;
padding:15px;
border:1px solid #ddd;
border-radius:10px;
outline:none;
}

.upload-area{
border:2px dashed #10b981;
padding:40px;
text-align:center;
border-radius:15px;
cursor:pointer;
transition:.3s;
}

.upload-area:hover{
background:#f0fdf4;
}

.upload-area i{
font-size:50px;
color:#10b981;
margin-bottom:10px;
}

.upload-area input{
display:none;
}

.upload-btn{
background:#059669;
color:white;
border:none;
padding:14px 20px;
border-radius:10px;
cursor:pointer;
font-weight:600;
}

.upload-btn:hover{
background:#047857;
}

/* CURRENT FILE */

.current-row{
display:flex;
justify-content:space-between;
align-items:center;
flex-wrap:wrap;
gap:15px;
}

.view-btn{
background:#10b981;
color:white;
padding:10px 15px;
border-radius:10px;
text-decoration:none;
}

/* TABLE */

table{
width:100%;
border-collapse:collapse;
}

table th{
background:#064e3b;
color:white;
padding:15px;
text-align:left;
}

table td{
padding:15px;
border-bottom:1px solid #eee;
}

.history-btn{
background:#059669;
padding:8px 12px;
border-radius:8px;
color:white;
text-decoration:none;
}

.delete-btn{
background:#ef4444;
padding:8px 12px;
border-radius:8px;
color:white;
text-decoration:none;
margin-left:5px;
}

.edit-btn{
background:#f59e0b;
padding:8px 12px;
border-radius:8px;
color:white;
text-decoration:none;
margin-left:5px;
}

@media(max-width:768px){

.current-row{
flex-direction:column;
align-items:flex-start;
}

body{
padding:15px;
}

}

</style>

</head>

<body>

<div class="page-title">

<h1>
<i class="fas fa-clock"></i>
Timetable Management
</h1>

<p>
Upload and manage lecture timetables
</p>

</div>

<?php echo $message; ?>

<!-- UPLOAD CARD -->

<div class="card">

<form method="POST"
enctype="multipart/form-data">

<div class="form-group">

<input
type="text"
name="title"
placeholder="Timetable Title"
required>

</div>

<label class="upload-area">

<i class="fas fa-file-pdf"></i>

<p>
Click here to choose a PDF file
</p>

<input
type="file"
name="file"
accept=".pdf"
required>

</label>

<br>

<button
type="submit"
name="upload"
class="upload-btn">

<i class="fas fa-upload"></i>
Upload Timetable

</button>

</form>

</div>

<!-- CURRENT TIMETABLE -->

<div class="card">

<h3 style="margin-bottom:15px;">
Current Timetable
</h3>

<?php if($currentFile){ ?>

<div class="current-row">

<div>

<b>
<?php echo htmlspecialchars($currentFile['title']); ?>
</b>

<br>

Uploaded:
<?php echo date(
'd M Y',
strtotime($currentFile['uploaded_at'])
); ?>

</div>

<a
class="view-btn"
target="_blank"
href="../uploads/timetable/<?php echo $currentFile['file_name']; ?>">

View PDF

</a>

</div>

<?php } else { ?>

<p>No timetable uploaded yet.</p>

<?php } ?>

</div>

<!-- HISTORY -->

<div class="card">

<h3 style="margin-bottom:20px;">
Upload History
</h3>

<table>

<tr>
<th>Title</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php

$history = $conn->query("
SELECT *
FROM timetable
ORDER BY id DESC
");

while($row = $history->fetch_assoc()){

?>

<tr>

<td>
<?php echo htmlspecialchars($row['title']); ?>
</td>

<td>
<?php echo $row['uploaded_at']; ?>
</td>

<td>

<a class="history-btn"
target="_blank"
href="../uploads/timetable/<?php echo $row['file_name']; ?>">
View
</a>
<a class="edit-btn"
href="edit_timetable.php?id=<?php echo $row['id']; ?>">
Edit
</a>

<a class="delete-btn"
href="delete_timetable.php?id=<?php echo $row['id']; ?>"
onclick="return confirm('Delete this timetable?')">
Delete
</a>

</td>

</tr>

<td>


</td>


<?php } ?>


</table>

</div>

</body>
</html>