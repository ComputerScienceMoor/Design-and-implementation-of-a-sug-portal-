<?php
session_start();
include("db.php");

if(!isset($_POST['message'])){
    exit();
}

$message = strtolower(trim($_POST['message']));

if(!isset($_SESSION['student_id'])){
    echo "Please login first.";
    exit();
}

$student_id = $_SESSION['student_id'];

/* STUDENT INFO */

$stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
$stmt->bind_param("i",$student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

$name = $student['full_name'];
$category = ucfirst($student['category']);
$department = $student['department'];

/* DUES */

$dues = ($student['category']=="fresher") ? 5000 : 4500;

/* PAYMENT STATUS */

$paymentQuery = $conn->prepare("
SELECT * FROM payments
WHERE student_id=?
AND verified=1
");

$paymentQuery->bind_param("i",$student_id);
$paymentQuery->execute();

$paymentResult = $paymentQuery->get_result();

$paid = ($paymentResult->num_rows > 0);

/* GREETING */

if(
strpos($message,"hi") !== false ||
strpos($message,"hello") !== false ||
strpos($message,"hey") !== false
){

echo "
Hello <b>$name</b> 👋<br><br>

Welcome to the SUG Portal Assistant.<br><br>

You can ask me about:<br>
✅ SUG dues<br>
✅ Payment status<br>
✅ Profile information<br>
✅ Receipt download<br>
✅ Department<br>
✅ Announcements
";

}

/* WHO AM I */

elseif(
strpos($message,"my profile") !== false ||
strpos($message,"who am i") !== false
){

echo "
<b>Student Information</b><br><br>

👤 Name: $name<br>
🏫 Department: $department<br>
🎓 Category: $category
";

}

/* DEPARTMENT */

elseif(
strpos($message,"department") !== false
){

echo "
You belong to:<br><br>

🏫 <b>$department</b>
";

}

/* CATEGORY */

elseif(
strpos($message,"category") !== false ||
strpos($message,"fresher") !== false ||
strpos($message,"staylite") !== false
){

echo "
Your student category is:<br><br>

🎓 <b>$category</b>
";

}

/* DUES */

elseif(
strpos($message,"dues") !== false ||
strpos($message,"amount") !== false ||
strpos($message,"how much") !== false
){

echo "
Your SUG dues is:<br><br>

💰 <b>₦".number_format($dues)."</b><br><br>

Category: $category
";

}

/* PAYMENT STATUS */

elseif(
strpos($message,"status") !== false ||
strpos($message,"paid") !== false ||
strpos($message,"payment") !== false
){

if($paid){

echo "
✅ Your SUG payment has been verified successfully.
";

}else{

echo "
❌ No verified payment found.<br><br>

Please complete your dues payment.
";

}

}

/* RECEIPT */

elseif(
strpos($message,"receipt") !== false
){

if($paid){

echo "
✅ Your receipt is available.<br><br>

Go to Dashboard → Download Receipt.
";

}else{

echo "
You must complete payment before downloading a receipt.
";

}

}

/* ANNOUNCEMENT */

elseif(
strpos($message,"announcement") !== false ||
strpos($message,"news") !== false
){

$result = $conn->query("
SELECT * FROM announcements
ORDER BY id DESC
LIMIT 1
");

if($result && $result->num_rows > 0){

$row = $result->fetch_assoc();

echo "
📢 <b>".$row['title']."</b><br><br>
".$row['message'];

}else{

echo "
No announcement available at the moment.
";

}

}

/* HOW TO PAY */

elseif(
strpos($message,"pay") !== false
){

echo "
To pay your SUG dues:<br><br>

1️⃣ Click <b>Pay SUG Dues</b><br>
2️⃣ Complete payment<br>
3️⃣ Receive confirmation<br>
4️⃣ Download receipt
";

}

/* CONTACT */

elseif(
strpos($message,"contact") !== false ||
strpos($message,"support") !== false
){

echo "
📞 Contact SUG Office<br><br>

Email: sug@fcahpt.edu.ng<br>
Office Hours: 8am - 4pm
";

}

/* HELP */

elseif(
strpos($message,"help") !== false
){

echo "
Available Commands:<br><br>

• My profile<br>
• Department<br>
• Category<br>
• SUG dues<br>
• Payment status<br>
• Receipt<br>
• Announcement<br>
• Contact
";

}

/* HOW ARE YOU */

elseif(
    strpos($message,"how are you") !== false ||
    strpos($message,"how are you doing") !== false ||
    strpos($message,"how is your day") !== false
    ){
    
    echo "
    😊 I'm doing great, thank you for asking!<br><br>
    
    I'm your SUG Portal Assistant and I'm here to help you with:<br><br>
    
    • SUG dues information<br>
    • Payment status<br>
    • Student profile details<br>
    • Receipt download<br>
    • Announcements
    ";
    
    }

    /* THANK YOU */

elseif(
    strpos($message,"thank") !== false
    ){
    
    echo "
    😊 You're welcome, $name.<br><br>
    Feel free to ask if you need any help.
    ";
    
    }
    
    /* BYE */
    
    elseif(
    strpos($message,"bye") !== false ||
    strpos($message,"goodbye") !== false
    ){
    
    echo "
    👋 Goodbye $name.<br><br>
    Have a wonderful day.
    ";
    
    }
    
    /* WHO CREATED YOU */
    
    elseif(
    strpos($message,"who created you") !== false ||
    strpos($message,"who made you") !== false
    ){
    
    echo "
    🤖 I am the SUG Portal Assistant developed to help students manage dues payments and access portal services.
    ";
    
    }

    else{

        $responses = [
        
        "🤔 I don't understand that yet. Try asking about your payment status or dues.",
        
        "😊 I'm still learning. Ask me about receipts, dues, announcements or payments.",
        
        "🤖 I couldn't understand that question. Type 'help' to see what I can do."
        
        ];
        
        echo $responses[array_rand($responses)];
        
        }

/* DEFAULT */

else{

echo "
🤖 Sorry, I didn't understand that.<br><br>

Try asking:<br><br>

• What is my department?<br>
• What is my category?<br>
• How much is my dues?<br>
• Check my payment status<br>
• Download receipt<br>
• Any announcements?
";

}
?>