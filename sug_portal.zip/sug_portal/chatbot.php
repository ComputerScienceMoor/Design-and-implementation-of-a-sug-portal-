<?php
session_start();
include("db.php");

if (!isset($_POST['message'])) {
    exit();
}

$message = strtolower(trim($_POST['message']));

if (strpos($message, "dues") !== false) {
    echo "The current SUG dues is ₦2,000.";
}

elseif (strpos($message, "status") !== false) {

    $student_id = $_SESSION['student_id'];

    $stmt = $conn->prepare("SELECT * FROM payments WHERE student_id=? AND verified=1");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Your payment has been successfully verified.";
    } else {
        echo "You have not completed your SUG payment.";
    }
}

elseif (strpos($message, "receipt") !== false) {
    echo "Your receipt is available after successful payment verification.";
}

elseif (strpos($message, "how") !== false) {
    echo "Login to your dashboard and click on 'Pay SUG Dues' to complete payment.";
}

elseif (strpos($message, "hello") !== false || strpos($message, "hi") !== false) {
    echo "Hello 👋 How can I assist you today?";
}

else {
    echo "I can help you with dues amount, payment status, receipt, or how to pay.";
}
?>